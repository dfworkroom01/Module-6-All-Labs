import React from 'react';

const Greeting = ({ name, children }) => {
  const greetingName = name || 'World';
  
  return (
    <div>
      <h1>
        Hello {greetingName}
        {children && <span> {children}</span>}
      </h1>
    </div>
  );
};

export default Greeting;
