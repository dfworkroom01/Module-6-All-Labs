import React from "react";
import Greeting from "./Greeting";

const App = () => {
  return (
    <div>
      <Greeting name="John"></Greeting>
      <Greeting>, this is Lab 1 Module 6!</Greeting>
    </div>
  );
};

export default App;
