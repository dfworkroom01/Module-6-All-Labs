export const cats = [
    { id: 1, name: 'Cheetah', latinName: 'Acinonyx jubatus', image: 'https://via.placeholder.com/150/FFA500/FFFFFF?text=Cheetah' },
    { id: 2, name: 'Cougar', latinName: 'Puma concolor', image: 'https://via.placeholder.com/150/8B4513/FFFFFF?text=Cougar' },
    { id: 3, name: 'Jaguar', latinName: 'Panthera onca', image: 'https://via.placeholder.com/150/FFD700/FFFFFF?text=Jaguar' },
    { id: 4, name: 'Leopard', latinName: 'Panthera pardus', image: 'https://via.placeholder.com/150/DAA520/FFFFFF?text=Leopard' },
    { id: 5, name: 'Lion', latinName: 'Panthera leo', image: 'https://via.placeholder.com/150/FF4500/FFFFFF?text=Lion' },
    { id: 6, name: 'Snow Leopard', latinName: 'Panthera uncia', image: 'https://via.placeholder.com/150/ADD8E6/FFFFFF?text=Snow+Leopard' },
    { id: 7, name: 'Tiger', latinName: 'Panthera tigris', image: 'https://via.placeholder.com/150/FF6347/FFFFFF?text=Tiger' },
  ];
  