// src/App.js
import React from 'react';
import BigCats from './components/BigCats';

const App = () => {
  return (
    <div>
      <BigCats />
    </div>
  );
};

export default App;
