import React from 'react';
import SingleCat from './SingleCat';
import { cats } from '../data';
import './BigCats.css'; // Import CSS for styling

const BigCats = () => {
  return (
    <div className="big-cats">
      <h1>Big Cats</h1>
      <div className="cat-grid">
        {cats.map(cat => (
          <SingleCat key={cat.id} cat={cat} />
        ))}
      </div>
    </div>
  );
};

export default BigCats;
