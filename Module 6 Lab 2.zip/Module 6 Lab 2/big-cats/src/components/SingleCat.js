import React from 'react';
import './SingleCat.css'; // Import CSS for styling

const SingleCat = ({ cat }) => {
  return (
    <div className="single-cat">
      <img src={cat.image} alt={cat.name} className="cat-image" />
      <div className="cat-info">
        <h3>{cat.name}</h3>
        <p>{cat.latinName}</p>
      </div>
    </div>
  );
};

export default SingleCat;
