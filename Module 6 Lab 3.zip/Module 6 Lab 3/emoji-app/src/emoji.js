import React from 'react';

function Emoji({ mood }) {
  let emoji;

  switch (mood) {
    case 'happy':
      emoji = '😊';
      break;
    case 'tired':
      emoji = '😴';
      break;
    case 'stressed':
      emoji = '😟';
      break;
    case 'really stressed':
      emoji = '😣';
      break;
    case 'giving up':
      emoji = '😩';
      break;
    case 'ecstatic':
      emoji = '🥳';
      break;
    default:
      emoji = '😊'; // Default emoji
  }

  return (
    <div>
      <span style={{ fontSize: '2rem' }}>
        {emoji}
      </span>
    </div>
  );
}

export default Emoji;
