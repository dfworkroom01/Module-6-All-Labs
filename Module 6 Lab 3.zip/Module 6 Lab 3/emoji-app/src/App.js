import React from 'react';
import MoodChanger from './MoodChanger';
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>Emoji App</h1> {/* Updated heading */}
      <MoodChanger />
    </div>
  );
}

export default App;
