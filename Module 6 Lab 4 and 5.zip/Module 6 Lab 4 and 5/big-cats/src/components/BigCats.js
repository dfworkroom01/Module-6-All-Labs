import React, { useState } from 'react';
import SingleCat from './SingleCat';
import AddCatForm from './AddCatForm';
import { cats as initialCats } from '../data';
import './BigCats.css';

const BigCats = () => {
  const [catList, setCatList] = useState(initialCats);

  const addCat = (newCat) => {
    setCatList((prevCats) => [...prevCats, newCat]);
  };

  const deleteCat = (id) => {
    setCatList((prevCats) => prevCats.filter(cat => cat.id !== id));
  };

  const sortCatsAlphabetically = () => {
    const sortedCats = [...catList].sort((a, b) => a.name.localeCompare(b.name));
    setCatList(sortedCats);
  };

  const reverseCats = () => {
    setCatList([...catList].reverse());
  };

  const filterPanthera = () => {
    const filteredCats = initialCats.filter(cat => cat.latinName.includes('Panthera'));
    setCatList(filteredCats);
  };

  const resetList = () => {
    setCatList(initialCats);
  };

  return (
    <div className="big-cats">
      <h1>Big Cats</h1>
      <AddCatForm addCat={addCat} />
      <div className="button-container">
        <button onClick={sortCatsAlphabetically}>Sort Alphabetically</button>
        <button onClick={reverseCats}>Reverse List</button>
        <button onClick={filterPanthera}>Show Panthera Family</button>
        <button onClick={resetList}>Reset List</button>
      </div>
      <div className="cat-grid">
        {catList.map(cat => (
          <div key={cat.id} className="cat-item">
            <SingleCat cat={cat} />
            <button onClick={() => deleteCat(cat.id)} className="delete-button">Delete</button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default BigCats;
