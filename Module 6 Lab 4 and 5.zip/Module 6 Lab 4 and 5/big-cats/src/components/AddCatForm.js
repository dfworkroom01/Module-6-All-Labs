import React, { useState } from 'react';

const AddCatForm = ({ addCat }) => {
  const [name, setName] = useState('');
  const [latinName, setLatinName] = useState('');
  const [image, setImage] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    const newCat = { id: Date.now(), name, latinName, image };
    addCat(newCat);
    setName('');
    setLatinName('');
    setImage('');
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        placeholder="Cat Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
        required
      />
      <input
        type="text"
        placeholder="Latin Name"
        value={latinName}
        onChange={(e) => setLatinName(e.target.value)}
        required
      />
      <input
        type="text"
        placeholder="Image URL"
        value={image}
        onChange={(e) => setImage(e.target.value)}
        required
        title="Example: https://via.placeholder.com/150/FF4500/FFFFFF?text=Lion"  // Add a tooltip for the URL example
      />
      <button type="submit">Add</button>
    </form>
  );
};

export default AddCatForm;
